using Microsoft.AspNetCore.Mvc;
using Paginacion.Entities;
using Paginacion.Services.Contracts;


namespace Paginacion.Controllers;
[ApiController]
[Route("/api/[controller]")]
public class GuitarController(IGuitarService guitarService):ControllerBase
{
    [HttpGet]
    public async Task<ApiResponses> GetGuitars()
    {
        var guitars = await guitarService.ListAll();
        return new ApiResponses(success:true, message:null, data:guitars);
    }

    [HttpGet("pagination/{pageIndex}/{pageSize}")]
    public async Task<ActionResult<ApiResponses>> GetGuitars(int pageIndex, int pageSize)
    {
        var guitars = await guitarService.ListByPage(pageIndex, pageSize);
        return new ApiResponses(success:true, message:null, data:guitars);
    }
}