namespace Paginacion.Entities;

public class PaginatedList <T> (List<T> items, int pageIndex, int totalPage)
{
    public List<T> Items { get; set; } = items;
    public int PageIndex { get;} = pageIndex;
    public int TotalPage { get;} = totalPage;
    public bool HasPreviousPage => PageIndex > 1;
    public bool HasNextPage => PageIndex < TotalPage;
}