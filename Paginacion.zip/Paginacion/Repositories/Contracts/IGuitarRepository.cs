using Paginacion.Entities;

namespace Paginacion.Repositories.Contracts;

public interface IGuitarRepository
{
    Task<List<Guitar>> ListAll();
    Task<PaginatedList<Guitar>> ListByPage(int pageIndex, int pageSize);
}