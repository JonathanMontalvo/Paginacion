using Microsoft.EntityFrameworkCore;
using Paginacion.Data;
using Paginacion.Entities;
using Paginacion.Repositories.Contracts;

namespace Paginacion.Repositories;

public class GuitarRepository(AppDbContext context):IGuitarRepository
{
    public async Task<List<Guitar>> ListAll()
    {
        return await context.Guitar.ToListAsync();
    }

    public async Task<PaginatedList<Guitar>> ListByPage(int pageIndex, int pageSize)
    {
        var guitars = await context.Guitar
            .OrderBy(g => g.Id)
            .Skip((pageIndex - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();
        var count = await context.Guitar.CountAsync();
        var totalPage = (int) Math.Ceiling((double)count/pageSize);
        return new PaginatedList<Guitar>(guitars, pageIndex, totalPage);
    }
}