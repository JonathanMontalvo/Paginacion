using Paginacion.Entities;
using Paginacion.Repositories.Contracts;
using Paginacion.Services.Contracts;

namespace Paginacion.Services;

public class GuitarService(IGuitarRepository guitarRepository) : IGuitarService
{
    public async Task<List<Guitar>> ListAll()
    {
        return await guitarRepository.ListAll();
    }

    public async Task<PaginatedList<Guitar>> ListByPage(int page, int pageSize)
    {
        return await guitarRepository.ListByPage(page, pageSize);
    }
}