using Paginacion.Entities;

namespace Paginacion.Services.Contracts;

public interface IGuitarService
{
    Task<List<Guitar>> ListAll();
    Task<PaginatedList<Guitar>> ListByPage(int page, int pageSize);
}