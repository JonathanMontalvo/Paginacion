using Microsoft.EntityFrameworkCore;
using Paginacion.Entities;

namespace Paginacion.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Guitar> Guitar { get; set; }
}